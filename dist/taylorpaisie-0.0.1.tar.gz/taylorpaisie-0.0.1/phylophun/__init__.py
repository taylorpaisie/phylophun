#!/usr/bin/env python
from phylophun import get_fasta_file
from phylophun import get_gb_file
from phylophun import get_country_date
from phylophun import combining_fasta